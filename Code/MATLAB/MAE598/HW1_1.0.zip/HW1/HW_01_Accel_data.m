%% *This code reads the .csv files containing g-force or accel data and
 %  returns plots of the data in terms of linear acceleration vs. time, 
 %  as well as other useful information.*

%Clear all
clc;clear;clf;
%Define variable names for accel and gforce
ACCEL = [{'time'}, {'ax'}, {'ay'}, {'az'}, {'atotal'}];
GFORCE = [{'time'}, {'gFx'}, {'gFy'}, {'gFz'}, {'TgF'}];
%Define the target data analysis frequency in Hz  
analysisHz = 45;
%Set the smoothing widow multiplier
%   -The smoothing window size will be set as the product of this number
%    and the analysis Hz.
%   -The larger the multiplier, the smoother the data. 
%   -Setting this to 1 means the sliding window replaces each data point x
%    with the mean of the data over -0.5 to 0.5 seconds centered on x
smoothingNum = 10;

%% *Read data*

%Read file name
fname = '2024-01-31_03_100Hz.csv';
%Read data to table
T = readtable(fname);
%Get variable names
Vars = T.Properties.VariableNames;

%% *Process the data* 

%Create figure
figure(10);
%If Table is in Gforce, enter fcn Gf_to_Accel
if (isequal(Vars,GFORCE))
    %Convert g-force to linear acceleration
    T = Gf_to_Accel(T, ACCEL);
end
%Adjust the frequency of the data
T = adjustFrequency(T,analysisHz);
%Smooth out the noise
smoothingWindow = analysisHz*smoothingNum;
T = smoothTable(T, smoothingWindow);

%% *Plot data*

%Plot x,y,z accel
subplot(2,1,1); plot(T.time,[T.ax, T.ay, T.az]); grid on; xlabel('Time (sec)');
legend('ax','ay','az')
%Plot total accel
subplot(2,1,2); plot(T.time,T.atotal); grid on; xlabel('Time (sec)');
legend('acceleration')
